export interface TenantTheme {
  primary_color?: string;
  secondary_color?: string;
  logo_url?: string;
  font_family?: string;
}

export interface TenantSettings {
  theme?: TenantTheme;
  language?: 'ru' | 'kg' | 'en';
  timezone?: string;
  widget?: {
    show_prices?: boolean;
    show_duration?: boolean;
    allow_multi_service?: boolean;
  };
}

export interface Tenant {
  id: string;
  slug: string;
  name: string;
  type: 'SALON' | 'SOLO';
  settings: TenantSettings;
}

export async function getTenantFromHost(host: string): Promise<Tenant | null> {
  const subdomain = host.split('.')[0];
  
  if (subdomain === 'demo-salon') {
    return {
      id: 'demo-salon-id',
      slug: 'demo-salon',
      name: 'Демо Салон Красоты',
      type: 'SALON',
      settings: {
        theme: {
          primary_color: '#FF6B6B',
          secondary_color: '#4ECDC4',
        },
        language: 'ru',
        timezone: 'Asia/Bishkek',
        widget: {
          show_prices: true,
          show_duration: true,
          allow_multi_service: true
        }
      }
    };
  }
  
  if (subdomain === 'demo-solo') {
    return {
      id: 'demo-solo-id',
      slug: 'demo-solo',
      name: 'Мастер Алия',
      type: 'SOLO',
      settings: {
        theme: {
          primary_color: '#9B59B6',
          secondary_color: '#E74C3C',
        },
        language: 'ru',
        timezone: 'Asia/Bishkek',
        widget: {
          show_prices: true,
          show_duration: true,
          allow_multi_service: false
        }
      }
    };
  }
  
  return null;
}

export function applyTenantTheme(theme: TenantTheme): void {
  if (typeof window === 'undefined') return;
  
  const root = document.documentElement;
  
  if (theme.primary_color) {
    root.style.setProperty('--primary', theme.primary_color);
  }
  
  if (theme.secondary_color) {
    root.style.setProperty('--secondary', theme.secondary_color);
  }
  
  if (theme.font_family) {
    root.style.setProperty('--font-family', theme.font_family);
  }
}