/**
 * Tenant resolution and theming utilities
 */

export interface TenantTheme {
  primary_color?: string;
  secondary_color?: string;
  logo_url?: string;
  font_family?: string;
}

export interface TenantSettings {
  theme?: TenantTheme;
  language?: 'ru' | 'kg' | 'en';
  timezone?: string;
  widget?: {
    show_prices?: boolean;
    show_duration?: boolean;
    allow_multi_service?: boolean;
  };
}

export interface Tenant {
  id: string;
  slug: string;
  name: string;
  type: 'SALON' | 'SOLO';
  settings: TenantSettings;
}

/**
 * Get tenant from host header
 * This would typically call an API endpoint
 */
export async function getTenantFromHost(host: string): Promise<Tenant | null> {
  // In production, this would call: GET /api/tenants/resolve?host={host}
  // For now, return mock data for demo
  
  const subdomain = host.split('.')[0];
  
  if (subdomain === 'demo-salon') {
    return {
      id: 'demo-salon-id',
      slug: 'demo-salon',
      name: 'Демо Салон Красоты',
      type: 'SALON',
      settings: {
        theme: {
          primary_color: '#FF6B6B',
          secondary_color: '#4ECDC4',
        },
        language: 'ru',
        timezone: 'Asia/Bishkek',
        widget: {
          show_prices: true,
          show_duration: true,
          allow_multi_service: true
        }
      }
    };
  }
  
  if (subdomain === 'demo-solo') {
    return {
      id: 'demo-solo-id',
      slug: 'demo-solo',
      name: 'Мастер Алия',
      type: 'SOLO',
      settings: {
        theme: {
          primary_color: '#9B59B6',
          secondary_color: '#E74C3C',
        },
        language: 'ru',
        timezone: 'Asia/Bishkek',
        widget: {
          show_prices: true,
          show_duration: true,
          allow_multi_service: false
        }
      }
    };
  }
  
  return null;
}

/**
 * Apply tenant theme to CSS variables
 */
export function applyTenantTheme(theme: TenantTheme): void {
  if (typeof window === 'undefined') return;
  
  const root = document.documentElement;
  
  if (theme.primary_color) {
    // Convert hex to HSL for CSS variables
    const hsl = hexToHSL(theme.primary_color);
    root.style.setProperty('--primary', hsl);
  }
  
  if (theme.secondary_color) {
    const hsl = hexToHSL(theme.secondary_color);
    root.style.setProperty('--secondary', hsl);
  }
  
  if (theme.font_family) {
    root.style.setProperty('--font-family', theme.font_family);
  }
}

/**
 * Convert hex color to HSL string for CSS variables
 */
function hexToHSL(hex: string): string {
  // Remove # if present
  hex = hex.replace('#', '');
  
  // Convert to RGB
  const r = parseInt(hex.substring(0, 2), 16) / 255;
  const g = parseInt(hex.substring(2, 4), 16) / 255;
  const b = parseInt(hex.substring(4, 6), 16) / 255;
  
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0, s = 0, l = (max + min) / 2;
  
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / d + 2) / 6; break;
      case b: h = ((r - g) / d + 4) / 6; break;
    }
  }
  
  h = Math.round(h * 360);
  s = Math.round(s * 100);
  l = Math.round(l * 100);
  
  return `${h} ${s}% ${l}%`;
}

